const CACHE = 'knjo-core-shell-v3';
const SHELL = ['/', '/index.html', '/app.css', '/app.js', '/ai-studio.js', '/manifest.webmanifest', '/pwa-register.js', '/assets/knjo-icon-192.png', '/assets/knjo-icon-512.png', '/assets/knjo-emblem.png'];
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;
  if (!SHELL.includes(url.pathname) && url.pathname !== '/') return;
  event.respondWith(fetch(event.request).then(response => { if (response.ok) { const copy = response.clone(); caches.open(CACHE).then(cache => cache.put(event.request, copy)); } return response; }).catch(async () => (await caches.match(event.request)) || (await caches.match('/index.html'))));
});
