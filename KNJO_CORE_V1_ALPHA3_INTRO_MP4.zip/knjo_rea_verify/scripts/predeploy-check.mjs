import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = process.cwd();
const failures = [];
const pass = (s) => console.log(`PASS ${s}`);
const fail = (s) => { failures.push(s); console.error(`FAIL ${s}`); };
const read = (p) => readFileSync(join(root, p), 'utf8');

for (const p of [
  'netlify.toml','package.json','public/index.html','public/app.js','public/ai-studio.js','public/app.css',
  'public/manifest.webmanifest','public/pwa-register.js','public/sw.js',
  'public/assets/knjo-icon-192.png','public/assets/knjo-icon-512.png',
  'netlify/functions/_shared.mjs','netlify/functions/_ai-auth.mjs','netlify/functions/_ai-quality.mjs','netlify/functions/_provider-fetch.mjs','netlify/functions/ai-chat.mjs','netlify/functions/image-generate.mjs','netlify/functions/health.mjs',
  'netlify/functions/auth-login.mjs','netlify/functions/auth-me.mjs',
  'netlify/functions/auth-csrf.mjs','netlify/functions/auth-logout.mjs',
  'netlify/functions/tasks.mjs','netlify/functions/tasks-update.mjs',
  'netlify/functions/tasks-delete.mjs','scripts/hash-password.mjs'
]) existsSync(join(root,p)) ? pass(`Existe ${p}`) : fail(`Falta ${p}`);

const html = read('public/index.html');
if (/<script\s+type=["']module["']\s+src=["']\/app\.js["']/.test(html)) pass('La aplicación carga app.js como módulo ES');
else fail('index.html no carga app.js como módulo ES');
if (/href=["']\/manifest\.webmanifest["']/.test(html) && /src=["']\/pwa-register\.js["']/.test(html)) pass('Manifest y registro PWA enlazados');
else fail('Falta enlace del manifest o registro PWA');

const toml = read('netlify.toml');
for (const route of ['auth-login','auth-me','auth-csrf','auth-logout','tasks','tasks-update','tasks-delete','health','ai-chat','image-generate']) {
  if (toml.includes(`/.netlify/functions/${route}`)) pass(`Ruta Netlify ${route}`);
  else fail(`Falta redirect de ${route}`);
}
if (/publish\s*=\s*["']public["']/.test(toml) && /functions\s*=\s*["']netlify\/functions["']/.test(toml)) pass('Directorios publish/functions configurados');
else fail('Configuración publish/functions incorrecta');

const shared = read('netlify/functions/_shared.mjs');
if (shared.includes('AUTH_USERNAME') && shared.includes('AUTH_PASSWORD_HASH') && /scrypt\\\$\[a-f0-9\]\{32\}/.test(shared)) pass('Autenticación exige usuario y hash scrypt con formato validado');
else fail('Validación de credenciales incompleta');
if (shared.includes('knjo-core-tasks') && shared.includes('knjo-core-sessions') && shared.includes('requireCsrf')) pass('Persistencia y validación CSRF presentes');
else fail('No se detecta persistencia/CSRF esperada');
if (/import \{ connectLambda, getStore \} from ['"]@netlify\/blobs['"]/.test(shared) && /connectLambda\(event\)/.test(shared) && /knjoStore\('knjo-core-tasks', event\)/.test(shared)) pass('Blobs inicializa el contexto Lambda y recibe el evento por solicitud');
else fail('Blobs no inicializa el contexto Lambda en el adaptador principal');
const aiAuth = read('netlify/functions/_ai-auth.mjs');
if (/connectLambda\(event\)/.test(aiAuth) && /store\('knjo-core-sessions', event\)/.test(aiAuth)) pass('Autorización de IA inicializa Blobs con el evento de la solicitud');
else fail('Autorización de IA no inicializa el contexto Blobs');
if (/storage:\s*\{state:\s*'not-checked',verified:false/.test(shared) && /liveness:\s*\{state:\s*'ok',verified:true/.test(shared)) pass('Health no presenta Blobs como verificado sin una prueba real');
else fail('Health puede sobredeclarar el estado del almacenamiento');
if (/const usernameMatches=safeEqual\(input\.username,creds\.username\); const passwordMatches=await verifyPassword\(input\.password,creds\.passwordHash\); if\(!usernameMatches \\|\| !passwordMatches\)/.test(shared)) pass('Login verifica contraseña aunque el usuario no coincida');
else fail('Login puede omitir el cálculo de verificación de contraseña');

for (const [a,b] of [['app.js','public/app.js'],['app.css','public/app.css'],['index.html','public/index.html'],['sw.js','public/sw.js'],['pwa-register.js','public/pwa-register.js']]) {
  if (read(a) === read(`public/${b.split('/').pop()}`)) pass(`Copia raíz sincronizada: ${a}`);
  else fail(`Copia raíz desincronizada: ${a}`);
}

if (existsSync(join(root,'tests/ai-quality.test.mjs'))) pass('Pruebas de calidad IA presentes'); else fail('Faltan pruebas de calidad IA');

const jsFiles = [];
function walk(dir) { for (const ent of readdirSync(join(root,dir),{withFileTypes:true})) { const p=join(dir,ent.name); if(ent.isDirectory()) walk(p); else if(/\.(mjs|js)$/.test(ent.name)) jsFiles.push(p); } }
walk('public'); walk('netlify/functions'); walk('scripts'); walk('tests');
for (const p of jsFiles) {
  const r = spawnSync(process.execPath,['--check',p],{cwd:root,encoding:'utf8'});
  if (r.status===0) pass(`Sintaxis ${p}`); else fail(`Sintaxis ${p}: ${(r.stderr||r.stdout).trim()}`);
}

const pkg = JSON.parse(read('package.json'));
if (pkg.dependencies?.['@netlify/blobs']) pass('Dependencia @netlify/blobs declarada'); else fail('Falta @netlify/blobs');
if (pkg.engines?.node && Number(pkg.engines.node.replace(/\D/g,'')) >= 22) pass('Runtime Node 22+ declarado'); else fail('Runtime Node 22+ no declarado');
if (existsSync(join(root,'.env')) || existsSync(join(root,'netlify/.env'))) fail('Se encontró archivo .env local; no empaquetar secretos'); else pass('No hay archivos .env locales');

console.log(`\nResultado: ${failures.length ? `${failures.length} error(es)` : 'CHECKS ESTÁTICOS APROBADOS'}`);
if (failures.length) process.exitCode = 1;
