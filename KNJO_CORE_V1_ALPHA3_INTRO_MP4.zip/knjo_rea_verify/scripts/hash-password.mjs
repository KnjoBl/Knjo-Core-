import { randomBytes, scrypt as scryptCb } from 'node:crypto';
import { promisify } from 'node:util';
const scrypt=promisify(scryptCb);
if(process.argv.includes('--help')) { console.log('Genera AUTH_PASSWORD_HASH leyendo la contraseña desde stdin. No la pases como argumento.'); process.exit(0); }
let input=''; for await (const chunk of process.stdin) input += chunk;
const password=input.replace(/[\r\n]+$/,'');
if(password.length<14 || password.length>1024) { console.error('La contraseña debe tener entre 14 y 1024 caracteres.'); process.exit(1); }
const salt=randomBytes(16); const key=await scrypt(password,salt,64,{N:16384,r:8,p:1,maxmem:64*1024*1024});
process.stdout.write(`scrypt$${salt.toString('hex')}$${key.toString('hex')}\n`);
