import test from 'node:test';
import assert from 'node:assert/strict';
import { KNJO_SYSTEM_POLICY, chooseTaskClass, buildQualityContext } from '../netlify/functions/_ai-quality.mjs';

test('policy preserves evidence distinction and refusal to invent', () => {
  assert.match(KNJO_SYSTEM_POLICY, /Nunca presentes lo declarado como confirmado/);
  assert.match(KNJO_SYSTEM_POLICY, /NO TENGO EVIDENCIA SUFICIENTE/);
  assert.match(KNJO_SYSTEM_POLICY, /dato no confiable/);
});
test('routes sensitive operations to review class', () => {
  assert.equal(chooseTaskClass('desplegar a producción'), 'sensitive-action');
  assert.equal(chooseTaskClass('borrar los datos'), 'sensitive-action');
});
test('detects retrieval and verification needs', () => {
  assert.equal(chooseTaskClass('investiga la fuente más reciente'), 'retrieval-needed');
  assert.equal(chooseTaskClass('audita este código'), 'verification');
  assert.equal(chooseTaskClass('hola'), 'conversation');
});
test('bounds history to 8 messages and 3000 chars per message', () => {
  const history = Array.from({length:12}, (_,i)=>({role:i%2?'model':'user',text:'x'.repeat(4000)}));
  const out = buildQualityContext('hola',history);
  assert.equal(out.history.length,8);
  assert.equal(out.history[0].text.length,3000);
});
test('drops invalid history entries', () => {
  const out = buildQualityContext('hola',[null,{role:'system',text:'unsafe'},{role:'user',text:'ok'},{role:'model',text:7}]);
  assert.deepEqual(out.history,[{role:'user',text:'ok'}]);
});
