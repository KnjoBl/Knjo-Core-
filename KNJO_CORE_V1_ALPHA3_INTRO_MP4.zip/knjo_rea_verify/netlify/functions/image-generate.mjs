import { authorizeAI, reply, parseBody } from './_ai-auth.mjs';
import { fetchProviderJson } from './_provider-fetch.mjs';
const MODEL = process.env.GEMINI_IMAGE_MODEL || 'gemini-nano-banana-2.1';
const MIME = new Set(['image/png','image/jpeg','image/webp']);
export const handler = async (event) => {
  try {
    const auth=await authorizeAI(event); if(!auth.ok)return auth.response;
    const input=parseBody(event); if(!input||typeof input.prompt!=='string'||!input.prompt.trim()||input.prompt.length>6000) return reply(400,{error:{code:'INVALID_INPUT',message:'Escribe una descripción de imagen de hasta 6,000 caracteres.'}});
    const apiKey=process.env.GEMINI_API_KEY; if(!apiKey)return reply(503,{error:{code:'AI_NOT_CONFIGURED',message:'Generación de imágenes no configurada. Añade GEMINI_API_KEY en Netlify y vuelve a desplegar.'}});
    const parts=[{text:input.prompt.trim()}];
    if(input.image){
      if(typeof input.image.data!=='string'||input.image.data.length>5_500_000||!MIME.has(input.image.mimeType)) return reply(400,{error:{code:'INVALID_IMAGE',message:'La imagen debe ser PNG, JPEG o WebP y pesar menos de 4 MB.'}});
      const b64=input.image.data.replace(/^data:[^,]+,/,''); if(!/^[A-Za-z0-9+/]+={0,2}$/.test(b64))return reply(400,{error:{code:'INVALID_IMAGE',message:'El archivo de imagen no es válido.'}});
      parts.unshift({inline_data:{mime_type:input.image.mimeType,data:b64}});
    }
    const { response, data } = await fetchProviderJson(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':apiKey},body:JSON.stringify({contents:[{role:'user',parts}],generationConfig:{responseModalities:['TEXT','IMAGE']}})},45_000);
    if(!response.ok){
      const providerCode=String(data?.error?.status||data?.error?.code||'').toUpperCase();
      const providerMessage=String(data?.error?.message||'');
      const quota=/QUOTA_EXCEEDED|RESOURCE_EXHAUSTED/i.test(providerCode+' '+providerMessage);
      const rateLimited=response.status===429;
      const code=quota?'IMAGE_QUOTA_EXCEEDED':rateLimited?'IMAGE_RATE_LIMIT':response.status===400?'IMAGE_REQUEST_REJECTED':response.status===401||response.status===403?'IMAGE_PROVIDER_AUTH':'IMAGE_PROVIDER_ERROR';
      const message=quota?'La cuota de generación de imágenes de Gemini se agotó. Revisa la cuota y facturación del proyecto.':rateLimited?'Gemini está limitando temporalmente la generación. Espera un momento y vuelve a intentarlo.':response.status===400?'Gemini rechazó la solicitud. Verifica el modelo de imágenes y el archivo de referencia.':response.status===401||response.status===403?'Gemini rechazó la credencial o los permisos. Revisa GEMINI_API_KEY en Netlify.':'El proveedor no pudo generar la imagen. Inténtalo más tarde.';
      return reply(rateLimited?429:502,{error:{code,message}});
    }
    const responseParts=data?.candidates?.[0]?.content?.parts||[]; const imagePart=responseParts.find(p=>p.inlineData?.data||p.inline_data?.data); const text=responseParts.filter(p=>p.text).map(p=>p.text).join('\n').trim();
    const raw=imagePart?.inlineData||imagePart?.inline_data;
    if(!raw?.data||!MIME.has(raw.mimeType||raw.mime_type))return reply(502,{error:{code:'IMAGE_EMPTY_RESPONSE',message:text||'Gemini no devolvió una imagen utilizable.'}});
    return reply(200,{image:{mimeType:raw.mimeType||raw.mime_type,data:raw.data},text,model:MODEL});
  } catch(e) { return reply(502,{error:{code:e?.name==='AbortError'?'IMAGE_TIMEOUT':'IMAGE_UNAVAILABLE',message:e?.name==='AbortError'?'La generación tardó demasiado. Inténtalo de nuevo.':'No fue posible generar la imagen en este momento.'}}); }
};
