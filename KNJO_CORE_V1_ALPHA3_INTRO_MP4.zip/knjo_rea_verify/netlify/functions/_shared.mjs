import { connectLambda, getStore } from '@netlify/blobs';

const KNJO_BLOBS_SITE_ID = process.env.NETLIFY_SITE_ID || '5fd1eff0-4605-4ed2-8406-37ceb1903667';
function knjoStore(name, event) {
  const token = process.env.NETLIFY_AUTH_TOKEN;
  if (token) return getStore({ name, siteID: KNJO_BLOBS_SITE_ID, token });
  if (!event || typeof event !== 'object' || typeof event.blobs !== 'string') {
    throw new Error('Netlify Blobs no está inicializado: falta el contexto Lambda del evento.');
  }
  connectLambda(event);
  return getStore(name);
}
import { createHash, randomBytes, scrypt as scryptCb, timingSafeEqual, randomUUID } from 'node:crypto';
import { promisify } from 'node:util';
const scrypt = promisify(scryptCb);
const SESSION_TTL = 30 * 60 * 1000;
const SESSION_COOKIE = 'knjo_session';
const CSRF_COOKIE = 'knjo_csrf';
const validPriorities = new Set(['low','medium','high','urgent']);
const validStatuses = new Set(['todo','in_progress','done','cancelled']);
const hash = (s) => createHash('sha256').update(String(s)).digest('hex');
const safeEqual = (a,b) => { const x=Buffer.from(String(a??'')); const y=Buffer.from(String(b??'')); return x.length===y.length && timingSafeEqual(x,y); };
const json = (statusCode, body, headers = {}, cookies = []) => ({
  statusCode,
  headers: { 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', 'x-content-type-options':'nosniff', 'referrer-policy':'same-origin', ...headers },
  ...(cookies.length ? { multiValueHeaders: { 'set-cookie': cookies } } : {}),
  body: body === null ? '' : JSON.stringify(body)
});
const error = (status, code, message) => json(status, { error: { code, message } });
function cookiesOf(header='') { const out={}; for(const part of header.split(';')) { const i=part.indexOf('='); if(i>0) out[part.slice(0,i).trim()]=part.slice(i+1).trim(); } return out; }
function cookie(name,value,{httpOnly=true,maxAge=1800}={}) { return `${name}=${value}; Path=/; SameSite=Strict; Max-Age=${maxAge}; Secure${httpOnly?'; HttpOnly':''}`; }
function requireSameOrigin(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const host = event.headers?.host || event.headers?.Host;
  if (!origin || !host) return false;
  try { const u=new URL(origin); return (u.protocol==='https:' || u.hostname==='localhost') && u.host.toLowerCase()===host.toLowerCase(); } catch { return false; }
}
function envCredentials() {
  const username=process.env.AUTH_USERNAME, passwordHash=process.env.AUTH_PASSWORD_HASH;
  if(!username || !/^[A-Za-z0-9._-]{3,64}$/.test(username) || !passwordHash || !/^scrypt\$[a-f0-9]{32}\$[a-f0-9]{128}$/.test(passwordHash)) return null;
  return {username,passwordHash};
}
async function verifyPassword(password, encoded) {
  const m=/^scrypt\$([a-f0-9]{32})\$([a-f0-9]{128})$/.exec(encoded||'');
  if(!m || typeof password!=='string' || password.length>1024) return false;
  const actual=await scrypt(password,Buffer.from(m[1],'hex'),64,{N:16384,r:8,p:1,maxmem:64*1024*1024});
  return timingSafeEqual(actual,Buffer.from(m[2],'hex'));
}
async function sessionFor(event) {
  const c=cookiesOf(event.headers?.cookie || event.headers?.Cookie || '');
  const id=c[SESSION_COOKIE]; if(!id || !/^[A-Za-z0-9_-]{43}$/.test(id)) return null;
  const store=knjoStore('knjo-core-sessions', event); const key=hash(id);
  const session=await store.get(key,{type:'json'});
  if(!session || session.expiresAt<=Date.now()) { if(session) await store.delete(key); return null; }
  return {store,key,session,cookies:c};
}
async function requireSession(event) { return await sessionFor(event); }
async function requireCsrf(event, found) {
  const token=event.headers?.['x-csrf-token'] || event.headers?.['X-Csrf-Token'];
  return !!(token && found?.cookies?.[CSRF_COOKIE] && safeEqual(token,found.cookies[CSRF_COOKIE]) && safeEqual(hash(token),found.session.csrfHash));
}
function bodyOf(event) { try { const b=event.body || ''; if(!b) return {}; const parsed=JSON.parse(b); return parsed && typeof parsed==='object' && !Array.isArray(parsed) ? parsed : null; } catch { return null; } }
function validDate(v) { if(v===undefined || v===null || v==='') return ''; if(typeof v!=='string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return null; const d=new Date(v+'T00:00:00.000Z'); return !Number.isNaN(d.getTime()) && d.toISOString().slice(0,10)===v ? v : null; }
function cleanTask(input, previous={}) {
  if(!input || typeof input!=='object' || Array.isArray(input)) return null;
  const title=typeof input.title==='string' ? input.title.trim() : previous.title || '';
  const description=input.description===undefined ? (previous.description||'') : input.description;
  const priority=input.priority===undefined ? (previous.priority||'medium') : input.priority;
  const status=input.status===undefined ? (previous.status||'todo') : input.status;
  const dueDate=validDate(input.dueDate===undefined ? (previous.dueDate||'') : input.dueDate);
  if(!title || title.length>200 || typeof description!=='string' || description.length>5000 || !validPriorities.has(priority) || !validStatuses.has(status) || dueDate===null) return null;
  const now=new Date().toISOString();
  return { id:previous.id || randomUUID(), title, description, priority, status, dueDate, createdAt:previous.createdAt || now, updatedAt:now };
}
function taskPrefix(username) { return `tasks/${hash(username)}/`; }
async function listTasks(username, event) {
  const store=knjoStore('knjo-core-tasks', event); const prefix=taskPrefix(username); const result=await store.list({prefix});
  const tasks=[]; for(const item of result.blobs || []) { const t=await store.get(item.key,{type:'json'}); if(t && typeof t==='object') tasks.push(t); }
  return tasks.sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)));
}
export async function handle(event, route) {
  const method=(event.httpMethod||'GET').toUpperCase();
  if(method==='OPTIONS') return json(204,null,{'allow':'GET, POST, OPTIONS'});
  if(route==='health') return method==='GET' ? json(200,{service:'knjo-core',version:'1.0.0-alpha.3+tasks.0.3',liveness:{state:'ok',verified:true},storage:{state:'not-checked',verified:false,reason:'Este endpoint solo confirma que la función responde; no ejecuta una operación de lectura/escritura en Blobs.'},capabilities:{externalProviders:{state:'not-configured',verified:false}}}) : json(405,{error:{code:'METHOD_NOT_ALLOWED',message:'Método no permitido.'}},{allow:'GET'});
  const creds=envCredentials();
  if(route==='auth-login') {
    if(method!=='POST') return error(405,'METHOD_NOT_ALLOWED','Método no permitido.');
    if(!requireSameOrigin(event)) return error(403,'FORBIDDEN','Origen no autorizado.');
    if(!creds) return error(503,'AUTH_NOT_CONFIGURED','Configura AUTH_USERNAME y AUTH_PASSWORD_HASH en Netlify.');
    const input=bodyOf(event); if(!input || typeof input.username!=='string' || typeof input.password!=='string' || input.username.length>64 || input.password.length>1024) return error(400,'INVALID_INPUT','Datos de acceso inválidos.');
    const headers=event.headers||{}; const ip=headers['x-nf-client-connection-ip']||headers['x-forwarded-for']?.split(',')[0]?.trim()||'unknown';
    const limits=knjoStore('knjo-core-login-limits', event); const lk=hash(ip); const now=Date.now(); let rec=await limits.get(lk,{type:'json'});
    if(rec && rec.resetAt>now && rec.count>=5) return json(429,{error:{code:'TOO_MANY_REQUESTS',message:'Demasiados intentos. Espera 15 minutos.'}},{'retry-after':String(Math.ceil((rec.resetAt-now)/1000))});
    const usernameMatches=safeEqual(input.username,creds.username); const passwordMatches=await verifyPassword(input.password,creds.passwordHash); if(!usernameMatches || !passwordMatches) { rec=rec&&rec.resetAt>now?rec:{count:0,resetAt:now+900000}; rec.count++; await limits.setJSON(lk,rec); return error(401,'UNAUTHORIZED','Credenciales no válidas.'); }
    await limits.delete(lk);
    const id=randomBytes(32).toString('base64url'); const csrf=randomBytes(32).toString('base64url'); const session={username:creds.username,csrfHash:hash(csrf),createdAt:now,expiresAt:now+SESSION_TTL};
    await knjoStore('knjo-core-sessions', event).setJSON(hash(id),session);
    return json(200,{authenticated:true,user:{username:creds.username},csrfToken:csrf},{},[cookie(SESSION_COOKIE,id),cookie(CSRF_COOKIE,csrf,{httpOnly:false})]);
  }
  if(route==='auth-me' || route==='auth-csrf' || route==='auth-logout' || route==='tasks' || route==='tasks-update' || route==='tasks-delete') {
    const found=await requireSession(event); if(!found) return error(401,'UNAUTHORIZED','Inicia sesión para continuar.');
    found.session.expiresAt=Date.now()+SESSION_TTL; await found.store.setJSON(found.key,found.session);
    if(route==='auth-me') return method==='GET' ? json(200,{authenticated:true,user:{username:found.session.username},expiresAt:new Date(found.session.expiresAt).toISOString()}) : error(405,'METHOD_NOT_ALLOWED','Método no permitido.');
    if(route==='auth-csrf') return method==='GET' ? json(200,{csrfToken:found.cookies[CSRF_COOKIE]}) : error(405,'METHOD_NOT_ALLOWED','Método no permitido.');
    if(route==='auth-logout') {
      if(method!=='POST') return error(405,'METHOD_NOT_ALLOWED','Método no permitido.');
      if(!requireSameOrigin(event) || !(await requireCsrf(event,found))) return error(403,'FORBIDDEN','Solicitud no autorizada.');
      await found.store.delete(found.key);
      return json(200,{authenticated:false},{},[cookie(SESSION_COOKIE,'',{maxAge:0}),cookie(CSRF_COOKIE,'',{httpOnly:false,maxAge:0})]);
    }
    if(route==='tasks') {
      if(method==='GET') {
        const tasks=await listTasks(found.session.username, event); const q=event.queryStringParameters||{}; const today=new Date().toISOString().slice(0,10);
        const filtered=tasks.filter(t=>(!q.status||q.status==='all'||t.status===q.status)&&(!q.priority||q.priority==='all'||t.priority===q.priority)&&(!q.q||`${t.title} ${t.description}`.toLowerCase().includes(q.q.toLowerCase()))&&(!q.due||q.due==='all'||(q.due==='overdue'&&t.dueDate&&t.dueDate<today&&!['done','cancelled'].includes(t.status))||(q.due==='due_today'&&t.dueDate===today&&!['done','cancelled'].includes(t.status))||(q.due==='upcoming'&&t.dueDate>today&&!['done','cancelled'].includes(t.status))||(q.due==='no_due_date'&&!t.dueDate)||(q.due==='closed'&&['done','cancelled'].includes(t.status))));
        return json(200,{tasks:filtered});
      }
      if(method!=='POST') return error(405,'METHOD_NOT_ALLOWED','Método no permitido.');
      if(!requireSameOrigin(event)||!(await requireCsrf(event,found))) return error(403,'FORBIDDEN','Solicitud no autorizada.');
      const input=bodyOf(event); const task=cleanTask(input||{}); if(!task) return error(400,'VALIDATION_FAILED','Revisa título, descripción, prioridad, estado y fecha.');
      await knjoStore('knjo-core-tasks', event).setJSON(taskPrefix(found.session.username)+task.id,task); return json(201,{task});
    }
    if(route==='tasks-update') {
      if(method!=='POST') return error(405,'METHOD_NOT_ALLOWED','Método no permitido.');
      if(!requireSameOrigin(event)||!(await requireCsrf(event,found))) return error(403,'FORBIDDEN','Solicitud no autorizada.');
      const input=bodyOf(event); if(!input||typeof input.id!=='string'||!/^[0-9a-f-]{36}$/i.test(input.id)) return error(400,'VALIDATION_FAILED','Identificador de tarea inválido.');
      const store=knjoStore('knjo-core-tasks', event); const key=taskPrefix(found.session.username)+input.id; const previous=await store.get(key,{type:'json'}); if(!previous) return error(404,'NOT_FOUND','La tarea no existe.');
      const task=cleanTask(input,previous); if(!task) return error(400,'VALIDATION_FAILED','Revisa título, descripción, prioridad, estado y fecha.'); await store.setJSON(key,task); return json(200,{task});
    }
    if(route==='tasks-delete') {
      if(method!=='POST') return error(405,'METHOD_NOT_ALLOWED','Método no permitido.');
      if(!requireSameOrigin(event)||!(await requireCsrf(event,found))) return error(403,'FORBIDDEN','Solicitud no autorizada.');
      const input=bodyOf(event); if(!input||typeof input.id!=='string'||!/^[0-9a-f-]{36}$/i.test(input.id)) return error(400,'VALIDATION_FAILED','Identificador de tarea inválido.');
      const store=knjoStore('knjo-core-tasks', event); const key=taskPrefix(found.session.username)+input.id; const old=await store.get(key,{type:'json'}); if(!old) return error(404,'NOT_FOUND','La tarea no existe.'); await store.delete(key); return json(200,{deleted:true,id:input.id});
    }
  }
  return error(404,'NOT_FOUND','Ruta no encontrada.');
}
