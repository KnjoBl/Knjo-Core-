import { handle } from './_shared.mjs';
export const handler = async (event) => handle(event, 'health');
