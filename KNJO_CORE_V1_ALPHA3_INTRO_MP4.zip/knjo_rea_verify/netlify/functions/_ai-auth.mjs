import { createHash, timingSafeEqual } from 'node:crypto';
import { connectLambda, getStore } from '@netlify/blobs';

const SITE_ID = process.env.NETLIFY_SITE_ID || '5fd1eff0-4605-4ed2-8406-37ceb1903667';
const hash = (s) => createHash('sha256').update(String(s)).digest('hex');
const safeEqual = (a,b) => { const x=Buffer.from(String(a??'')); const y=Buffer.from(String(b??'')); return x.length===y.length && timingSafeEqual(x,y); };
function store(name, event) { const token=process.env.NETLIFY_AUTH_TOKEN; if(token) return getStore({name,siteID:SITE_ID,token}); if(!event || typeof event.blobs!=='string') throw new Error('Netlify Blobs no está inicializado: falta el contexto Lambda del evento.'); connectLambda(event); return getStore(name); }
function cookiesOf(header='') { const out={}; for(const part of header.split(';')) { const i=part.indexOf('='); if(i>0) out[part.slice(0,i).trim()]=part.slice(i+1).trim(); } return out; }
function sameOrigin(event) { const origin=event.headers?.origin||event.headers?.Origin; const host=event.headers?.host||event.headers?.Host; if(!origin||!host)return false; try { const u=new URL(origin); return (u.protocol==='https:'||u.hostname==='localhost')&&u.host.toLowerCase()===host.toLowerCase(); } catch{return false;} }
export async function authorizeAI(event) {
  const method=(event.httpMethod||'GET').toUpperCase();
  if(method!=='POST') return {ok:false,response:reply(405,{error:{code:'METHOD_NOT_ALLOWED',message:'Método no permitido.'}},{allow:'POST'})};
  if(!sameOrigin(event)) return {ok:false,response:reply(403,{error:{code:'FORBIDDEN',message:'Origen no autorizado.'}})};
  const cookies=cookiesOf(event.headers?.cookie||event.headers?.Cookie||''); const id=cookies.knjo_session; const csrfCookie=cookies.knjo_csrf;
  if(!id||!/^[A-Za-z0-9_-]{43}$/.test(id)) return {ok:false,response:reply(401,{error:{code:'UNAUTHORIZED',message:'Inicia sesión para continuar.'}})};
  const sessions=store('knjo-core-sessions', event); const key=hash(id); const session=await sessions.get(key,{type:'json'});
  if(!session||session.expiresAt<=Date.now()) return {ok:false,response:reply(401,{error:{code:'UNAUTHORIZED',message:'La sesión expiró. Vuelve a iniciar sesión.'}})};
  const csrf=event.headers?.['x-csrf-token']||event.headers?.['X-Csrf-Token'];
  if(!csrf||!csrfCookie||!safeEqual(csrf,csrfCookie)||!safeEqual(hash(csrf),session.csrfHash)) return {ok:false,response:reply(403,{error:{code:'CSRF_INVALID',message:'La sesión no autorizó esta solicitud.'}})};
  session.expiresAt=Date.now()+30*60*1000; await sessions.setJSON(key,session);
  return {ok:true,username:session.username};
}
export function reply(statusCode,body,headers={}) { return {statusCode,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'same-origin',...headers},body:body===null?'':JSON.stringify(body)}; }
export function parseBody(event) { try { const b=event.body||''; const x=JSON.parse(b); return x&&typeof x==='object'&&!Array.isArray(x)?x:null; } catch { return null; } }
