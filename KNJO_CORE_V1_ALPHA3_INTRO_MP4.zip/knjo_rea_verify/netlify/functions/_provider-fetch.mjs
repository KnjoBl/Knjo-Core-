/** Fetch a provider response and parse JSON under one timeout budget. */
export async function fetchProviderJson(url, options = {}, timeoutMs = 45_000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    const data = await response.json().catch((error) => {
      if (controller.signal.aborted || error?.name === 'AbortError') throw error;
      return null;
    });
    return { response, data };
  } finally {
    clearTimeout(timer);
  }
}
