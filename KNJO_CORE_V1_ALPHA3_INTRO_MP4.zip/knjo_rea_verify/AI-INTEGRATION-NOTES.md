# KNJO Core — AI Studio alpha

## Added, isolated modules
- `netlify/functions/_ai-auth.mjs`: session and CSRF validation for the new AI endpoints. It reads the existing `knjo-core-sessions` Netlify Blobs store and does not modify `_shared.mjs`.
- `netlify/functions/ai-chat.mjs`: authenticated Gemini text endpoint.
- `netlify/functions/image-generate.mjs`: authenticated Nano Banana image generation and optional image editing.
- `public/ai-studio.js`: chat UI, browser speech recognition/synthesis, image generation and download.

## Required Netlify environment variable
Set `GEMINI_API_KEY` in the site's environment variables with **Functions** scope (or All scopes). Do not put the key in client code or commit it. Then deploy the ZIP. Netlify environment changes only apply after a new deploy.

Optional variables:
- `GEMINI_CHAT_MODEL` (default `gemini-3.8-flash`)
- `GEMINI_IMAGE_MODEL` (default `gemini-nano-banana-2.1`)

The image model name and API availability must be supported by the Google AI project/account. Errors are returned without exposing the provider's raw response or key.

## Important status
Static syntax and predeploy checks pass. This is not yet deployed or verified against a live Gemini API key. The existing task and authentication source files are preserved. Voice recognition depends on browser support and microphone permission; speech synthesis uses the browser's Spanish voice when available.


## Límite de salida de KNJO Core

- El chat usa `GEMINI_CHAT_MAX_OUTPUT_TOKENS`; valor predeterminado: `32768`.
- Rango permitido: `1024` a `32768`; los valores fuera del rango se ajustan automáticamente.
- Configura la variable en Netlify con alcance **Functions** y vuelve a desplegar para aplicar el cambio.
- Un límite mayor permite respuestas más largas, pero no aumenta la cuota del proyecto ni elimina errores 429.
