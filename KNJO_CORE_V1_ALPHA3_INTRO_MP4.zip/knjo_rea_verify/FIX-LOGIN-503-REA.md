KNJO CORE V1 ALPHA3 — REA INGENIERÍA INVERSA
Corrección del bloqueo HTTP 503 en autenticación

EVIDENCIA CONFIRMADA
- La producción registró POST /api/auth/login con HTTP 503.
- En netlify/functions/_shared.mjs, el backend devuelve AUTH_NOT_CONFIGURED (503) si AUTH_USERNAME falta/no cumple formato o AUTH_PASSWORD_HASH falta/no cumple formato scrypt esperado.
- No se pudo verificar ni modificar el entorno de Netlify desde esta sesión; por tanto, no afirmar que la corrección en producción ya se aplicó.

VARIABLES OBLIGATORIAS EN NETLIFY
- AUTH_USERNAME: de 3 a 64 caracteres, solo letras, números, punto, guion o guion bajo.
- AUTH_PASSWORD_HASH: hash generado por scripts/hash-password.mjs; formato scrypt$ + 32 caracteres hex de salt + $ + 128 caracteres hex de clave derivada.
- Ámbito: Production y funciones/runtime. No guardar la contraseña en el repositorio.

GENERAR HASH DE FORMA SEGURA
Desde una terminal confiable, en la raíz del proyecto, ejecutar: node scripts/hash-password.mjs
Escribir una contraseña nueva de al menos 14 caracteres en la entrada estándar. Copiar únicamente el hash generado a AUTH_PASSWORD_HASH en Netlify. No incluir contraseña en comandos, archivos ni chats.

DESPLIEGUE REQUERIDO
Los cambios de variables necesitan un nuevo deploy/build. Desplegar mediante Git conectado o Netlify CLI para que se publiquen las funciones serverless y la dependencia @netlify/blobs. No usar solo arrastrar la carpeta public.

PRUEBAS DE ACEPTACIÓN
1. GET /health devuelve HTTP 200 y liveness=ok.
2. Login con credenciales configuradas devuelve éxito, no 503.
3. /api/auth/me reconoce la sesión.
4. Crear tarea, recargar y confirmar persistencia.
5. Editar estado, borrar tarea y comprobar respuesta.
6. Verificar en observability que ya no aparecen 503 en /api/auth/login.

ESTADO
Este paquete contiene el código base y este diagnóstico de remediación. No constituye evidencia de que la producción se haya corregido; requiere configurar las variables y publicar un deploy nuevo.
