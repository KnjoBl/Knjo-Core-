# KNJO Core — Correcciones P0 (paquete local)

Versión: `1.0.0-alpha.3-tasks.0.4-p0`

## Cambios aplicados
- Chat e imágenes comparten `netlify/functions/_provider-fetch.mjs` para limitar la llamada al proveedor y la lectura del cuerpo de respuesta dentro del mismo presupuesto de tiempo.
- El timeout interno de chat e imágenes queda en 45 segundos, con margen frente al límite síncrono de 60 segundos documentado por Netlify.
- Los errores de aborto durante la lectura del cuerpo no se silencian como si fueran una respuesta JSON inválida.
- La interfaz informa un límite de espera de 45 segundos en la generación de imágenes.
- Se añadieron pruebas unitarias del helper: respuesta HTTP del proveedor, timeout de red y timeout durante lectura del cuerpo.

## Validación local ejecutada
- `node --test tests/*.test.mjs`: 8/8 aprobadas.
- `npm run check`: aprobado.
- `npm run predeploy-check`: aprobado.
- `unzip -t`: debe ejecutarse también sobre el ZIP final.

## Límites explícitos
- No se ejecutaron login real, CRUD de tareas contra Netlify Blobs, llamadas reales a Gemini ni generación real de imágenes.
- No se verificaron las variables de entorno del sitio publicado.
- No se desplegó ni modificó producción.
- Estos resultados validan el código local y las pruebas simuladas, no el funcionamiento de producción.
